<?php
// Heading
$_['heading_title']    = 'Слайдер виробникiв - <a href = "https://t.me/alex_klimenko">Alex - telegram</a>';

// Text
$_['text_extension']   = 'Додаток';
$_['text_success']     = 'Успіх: Ви успішно змінили модуль';
$_['text_edit']        = 'Редагувати';

// Entry
$_['entry_name']       = 'Имя модуля';
$_['entry_banner']     = 'виробники';
$_['entry_banner_warning']     = 'выводяться тiльки выробники с фото!!!';
$_['entry_width']      = 'Ширина';
$_['entry_height']     = 'Висота';
$_['entry_status']     = 'Статус';
$_['entry_name2']   = 'Назва';

// Error
$_['error_permission'] = 'Увага: У вас немає прав на зміну!';
$_['error_name']       = 'Ім"я модуля має бути від 3 до 64 символів';
$_['error_width']      = 'Вкажіть ширину';
$_['error_height']     = 'Вкажіть висоту';
