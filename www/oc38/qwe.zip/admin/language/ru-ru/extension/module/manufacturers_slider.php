<?php
// Heading
$_['heading_title']    = 'Слайдер Производителей - <a href = "https://t.me/alex_klimenko">Alex - telegram</a>';

// Text
$_['text_extension']   = 'Расширение';
$_['text_success']     = 'Успех: Вы успешно модифицировали модуль';
$_['text_edit']        = 'Редактировать';

// Entry
$_['entry_name']       = 'Имя модуля';
$_['entry_banner']     = 'производители';
$_['entry_banner_warning']     = 'выводяться только производители с фотографиями!!!';
$_['entry_width']      = 'Ширина';
$_['entry_height']     = 'Высота';
$_['entry_status']     = 'Статус';
$_['entry_spaceBetween'] = 'расстояние';
$_['entry_autoplay'] = 'время ва мс';
$_['entry_name2']   = 'Заголовок';

// Error
$_['error_permission'] = 'Внимание: У вас нет прав на изменение!';
$_['error_name']       = 'Имя модуля должно быть от 3 до 64 символов';
$_['error_width']      = 'Укажите ширину';
$_['error_height']     = 'Укажите высоту';
