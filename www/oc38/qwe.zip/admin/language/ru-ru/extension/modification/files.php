<?php
// Heading
$_['heading_title']      = 'Файлы модификаций';

// Text
$_['text_modifications'] = 'Модификации';
$_['text_list']          = 'Список файлов';
$_['text_no_results']    = 'Нет файлов, измененных OCMOD.';
$_['text_file']          = 'Файл';
$_['text_modification']  = 'Модификация';
$_['text_version']       = 'Версия';
$_['text_author']        = 'Автор';